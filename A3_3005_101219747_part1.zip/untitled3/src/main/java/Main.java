/*
Developed by Austin Robert Rimmer SN:101219747 for Carleton's 3005 (databases) course on march 17 2024
this program is intended to be used in tandem with pgadmin 4

developed using jetbrain's intellij v2023.3

the purpose of this program is to add/manipulate instances of a student entity within a database
whether it be inserting, deletion, updating, and viewing
interaction occurs through the terminal (in my case using intellij vr 2023.3's terminal)

use of this code elsewhere as long as it does not breach your institutions academic integrity policies is fine (it took me maybe an hour so i wont stress over it :) )
|-> it is also why it is all in one super class (which isn't as pretty as I would've like but oh well)
 */

import javax.xml.transform.Result;
import java.sql.*;
import java.util.Scanner;

import static java.lang.Integer.parseInt;


//note all functions are static so they may interact with main (its been 2 years since ive last touched java)
//all functions require the Statement statement to properly be called by main and to avoid redundacy
public class Main {
    public static void main(String[] args){
        String url = "jdbc:postgresql://localhost:5432/students";
        String user= "postgres";
        String password = "Never1234";
        int choice = -1;
        String fn,ln,em,er;
        int stud;
        try{

            Class.forName( "org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(url,user,password);

            if(connection != null){
                System.out.println("CONNECTED TO DB\n");

                //my programs global statement
                Statement statement = connection.createStatement();


                Scanner userInput = new Scanner(System.in);


                //this is the switch statement for my text based menu ui
                //its set to negative 2 so that when the uses chooses to exit my nice message actually occurs
                //and the close statement also occurs
                while(choice != -2) {
                    switch (choice) {
                        case -1:
                            System.out.println("- press (1) to init database \n- press (2) to get all entries of database \n- press (3) to add a student \n- press (4) to update an email \n- press (5) to delete a student \n- press (6) to reset the database \n- press (0) to exit");
                            choice = parseInt((userInput.nextLine()));
                            break;
                        case 1:
                            System.out.println("Attempting to insert\n");
                            initData(statement);
                            choice = -1;
                            break;
                        case 2:
                            System.out.println("Attempting to get students\n");
                            getAllStudents(statement);
                            choice = -1;
                            break;
                        case 3:
                            System.out.println("Please write the first name, last name, email, and date of enrollment of the student you wish to add: ");
                            fn = userInput.nextLine();
                            ln = userInput.nextLine();
                            em = userInput.nextLine();
                            er = userInput.nextLine();

                            System.out.println("\nAttempting to add student\n");

                            addStudent(fn,ln, em, er, statement);

                            choice = -1;
                            break;
                        case 4:
                            System.out.println("Please write the student number and the new email for the student who's email you'd like to update: ");
                            stud = parseInt(userInput.nextLine());
                            em = userInput.nextLine();

                            System.out.println("Attempting to update student email\n");
                            updateEmail(stud,em,statement);

                            choice = -1;
                            break;
                        case 5:
                            System.out.println("Please write the student number of the student you wish to delete: ");
                            stud =  parseInt(userInput.nextLine());

                            System.out.println("Attempting to delete student\n");
                            deleteStudent(stud,statement);

                            choice = -1;
                            break;
                        case 6:
                            System.out.println("Attempting to reset database \n");
                            resetDB(statement);

                            choice = -1;
                            break;
                        case 0:
                            System.out.println("Have a nice day!");
                            System.exit(0);
                            break;
                    }
                }
                statement.close();

            }
            else{
                System.out.println("FAILED TO CONNECT\n");
            }
        }
        catch(Exception e){}

    }

    //gets all students
    public static void getAllStudents(Statement s){
        try {

            String query = "SELECT * FROM students ORDER BY student_id ASC";
            ResultSet resultSet = s.executeQuery(query);

            // Process the result set

            while (resultSet.next()) {
                //a while loop to get a subsequently print each of the specified columns value for each row
                int student_id = resultSet.getInt("student_id");
                String first_name = resultSet.getString("first_name");
                String last_name = resultSet.getString("last_name");
                String email = resultSet.getString("email");
                Date enrollment_date = resultSet.getDate("enrollment_date");

                //where the values are printed
                System.out.println("Student ID: " + student_id);
                System.out.println("First Name: " + first_name);
                System.out.println("Last Name: " + last_name);
                System.out.println("Email: " + email);
                System.out.println("Enrollment Date: " + enrollment_date);
                System.out.println();


            }
            System.out.println("got students successfully\n");
        }
        catch(Exception e){
            System.out.println("got students unsuccessfully\n");
        }

    }
    //adds a student
    public static void addStudent(String f_n, String l_n, String em, String d , Statement s){

        try {
            //an insert string for a student with the specified funct params into the table
            String insertQuery = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES ( " +" '" + f_n +"' , "+ "'" + l_n + "' , "+ "'"+ em +"' ,"+"'" + d + "')";

            //this is where we tell postgre to insert it
            s.executeUpdate(insertQuery);

        } catch (Exception e) {
            System.out.println("successfully added student");
        }
        System.out.println("successfully added student");
    }
    //intializes data for the table
    public static void initData(Statement s){
        try {
            //our insert string telling postgre to add the inital 3 students to the table
            String insertData = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES    ('John', 'Doe', 'john.doe@example.com', '2023-09-01'), ('Jane', 'Smith', 'jane.smith@example.com', '2023-09-01'), ('Jim', 'Beam', 'jim.beam@example.com', '2023-09-02')";
            //where its actually executed
            s.executeUpdate(insertData);

        }
        catch(Exception e){
            System.out.println("inserted data failure \n");
        }
        System.out.println("inserted data successfully \n");
    }

    //updates a students email
    public static void updateEmail(int stud, String email, Statement s){
        try{

            //string to update the old email of x student with the specified student number to a new email specified thru params
            String updateQuery = "UPDATE students " +
                    "SET email = '" + email + "' " +
                    "WHERE student_id = " + "'"+stud+"'";
            int rowsUpdated = s.executeUpdate(updateQuery);
        }
        catch(Exception e){
            System.out.println("failed to update email \n");
        }

        System.out.println("updated email successfully \n");
    }

    //deletes a student
    public static void deleteStudent(int stud, Statement s){
        try {
            //string to delete the specified student where their student number == the param
            String deleteQuery = "DELETE FROM students WHERE student_id = " + "'" + stud + "'";
            s.executeUpdate(deleteQuery);
        }
        catch(Exception e){
            System.out.println("failed to delete student \n");
        }
        System.out.println("deleted student successfully \n");
    }

    // hard resets the db by dropping then recreating it from scratch
    //used for my video example and for previous testing of how auto increment works
    //auto increment is also why this function completely destroys and recreates the table
    public static void resetDB( Statement s) {
        try {

            String dropTableQuery = "DROP TABLE IF EXISTS students";

            s.executeUpdate(dropTableQuery);

            String createQuery = "CREATE TABLE IF NOT EXISTS students (" +
                    "student_id SERIAL PRIMARY KEY," +
                    "first_name TEXT NOT NULL," +
                    "last_name TEXT NOT NULL," +
                    "email TEXT UNIQUE NOT NULL," +
                    "enrollment_date DATE" +
                    ")";

            s.executeUpdate(createQuery);

        }
        catch(Exception e){
            System.out.println("reset database failed \n");
        }
        System.out.println("reset database successfully \n");
    }

}
