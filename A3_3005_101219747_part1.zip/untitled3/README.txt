Developed by Austin Robert Rimmer SN:101219747 for Carleton's 3005 (databases) course on march 17 2024
this program is intended to be used in tandem with pgadmin 4

developed using jetbrain's intellij v2023.3

the purpose of this program is to add/manipulate instances of a student entity within a database
whether it be inserting, deletion, updating, and viewing
interaction occurs through the terminal (in my case using intellij vr 2023.3's terminal)

Launch Instructions(assuming youre using intellij):

1st replace the crnt user and password string with your own
run the project
interact with the program thru the terminal

https://youtu.be/cksxuKu5Q38